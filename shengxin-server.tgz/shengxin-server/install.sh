#!/usr/bin/env bash
# 省心 · 服务器一键安装脚本
# 用法（在服务器上，以 root 身份）：
#   tar xzf shengxin-server.tgz && cd shengxin-server && bash install.sh
# 做的事：装到 /opt/shengxin，注册为系统服务（只监听本机 127.0.0.1:8091），
# 再给现有的 Caddy 或 Nginx 追加一个新的站点，不改动已有站点（讲师日历不受影响）。
set -euo pipefail

DOMAIN_DEFAULT="sx.101-32-188-84.sslip.io"
PORT=8091
DIR=/opt/shengxin

[ "$(id -u)" = "0" ] || { echo "请用 root 运行：sudo bash install.sh"; exit 1; }
cd "$(dirname "$0")"

echo "== 省心服务器安装 =="
# 也可以用环境变量一次传入，不用逐项回答：SX_DOMAIN SX_INVITE SX_ADMIN_EMAIL SX_ADMIN_PASS
DOMAIN=${SX_DOMAIN:-}; INVITE=${SX_INVITE:-}; ADMIN_EMAIL=${SX_ADMIN_EMAIL:-}; ADMIN_PASS=${SX_ADMIN_PASS:-}
[ -n "$DOMAIN" ] || { read -rp "访问地址（直接回车用 $DOMAIN_DEFAULT）: " DOMAIN; DOMAIN=${DOMAIN:-$DOMAIN_DEFAULT}; }
[ -n "$INVITE" ] || read -rp "设置邀请码（家人注册时要填，建议 6 位以上）: " INVITE
[ -n "$INVITE" ] || { echo "邀请码不能为空"; exit 1; }
[ -n "$ADMIN_EMAIL" ] || read -rp "后台管理员邮箱（只用于登录后台，可随便填一个你的邮箱）: " ADMIN_EMAIL
[ -n "$ADMIN_PASS" ] || { read -rsp "后台管理员密码（至少 10 位）: " ADMIN_PASS; echo; }

if ss -ltn 2>/dev/null | grep -q ":$PORT "; then
  if ! systemctl is-active --quiet shengxin 2>/dev/null; then echo "端口 $PORT 已被别的程序占用，请改 install.sh 里的 PORT 再试"; exit 1; fi
fi

echo "-> 安装程序到 $DIR"
mkdir -p "$DIR"
systemctl stop shengxin 2>/dev/null || true
install -m 755 pocketbase "$DIR/pocketbase"
rm -rf "$DIR/pb_migrations" "$DIR/pb_hooks" "$DIR/pb_public"
cp -r pb_migrations pb_hooks pb_public "$DIR/"
umask 077; printf 'SX_INVITE=%s\n' "$INVITE" > "$DIR/env"; umask 022

cat > /etc/systemd/system/shengxin.service <<EOF
[Unit]
Description=ShengXin (省心) sync server
After=network.target

[Service]
Type=simple
WorkingDirectory=$DIR
EnvironmentFile=$DIR/env
ExecStart=$DIR/pocketbase serve --http 127.0.0.1:$PORT --dir $DIR/pb_data --migrationsDir $DIR/pb_migrations --hooksDir $DIR/pb_hooks --publicDir $DIR/pb_public
Restart=always
RestartSec=3
LimitNOFILE=4096

[Install]
WantedBy=multi-user.target
EOF

"$DIR/pocketbase" migrate up --dir "$DIR/pb_data" --migrationsDir "$DIR/pb_migrations" >/dev/null
"$DIR/pocketbase" superuser upsert "$ADMIN_EMAIL" "$ADMIN_PASS" --dir "$DIR/pb_data" >/dev/null
systemctl daemon-reload
systemctl enable --now shengxin
sleep 2
curl -fsS "http://127.0.0.1:$PORT/api/health" >/dev/null && echo "-> 服务已启动（127.0.0.1:$PORT）" || { echo "服务没有起来，查看：journalctl -u shengxin -n 50"; exit 1; }

# 每天凌晨 3 点备份数据，保留 14 天
cat > /etc/cron.daily/shengxin-backup <<EOF
#!/bin/sh
mkdir -p $DIR/backups
tar czf $DIR/backups/pb_data-\$(date +%F).tgz -C $DIR pb_data
find $DIR/backups -name 'pb_data-*.tgz' -mtime +14 -delete
EOF
chmod +x /etc/cron.daily/shengxin-backup

echo "-> 配置网站入口 https://$DOMAIN"
if command -v caddy >/dev/null 2>&1 && [ -f /etc/caddy/Caddyfile ]; then
  if grep -q "$DOMAIN" /etc/caddy/Caddyfile; then echo "Caddyfile 里已有 $DOMAIN，跳过"; else
    cp /etc/caddy/Caddyfile "/etc/caddy/Caddyfile.bak.$(date +%s)"
    printf '\n%s {\n\treverse_proxy 127.0.0.1:%s\n\trequest_body {\n\t\tmax_size 10MB\n\t}\n}\n' "$DOMAIN" "$PORT" >> /etc/caddy/Caddyfile
    caddy validate --config /etc/caddy/Caddyfile >/dev/null && systemctl reload caddy && echo "-> 已加入 Caddy，证书会自动申请"
  fi
elif command -v nginx >/dev/null 2>&1; then
  CONF_DIR=/etc/nginx/conf.d; [ -d "$CONF_DIR" ] || CONF_DIR=/etc/nginx/sites-enabled
  CONF="$CONF_DIR/shengxin.conf"
  cat > "$CONF" <<EOF
server {
    listen 80;
    server_name $DOMAIN;
    client_max_body_size 10m;
    location / {
        proxy_pass http://127.0.0.1:$PORT;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header Connection '';
        proxy_buffering off;
        proxy_read_timeout 360s;
    }
}
EOF
  if nginx -t 2>/dev/null; then systemctl reload nginx; echo "-> 已加入 Nginx（$CONF）"; else rm -f "$CONF"; echo "Nginx 配置检查没通过，已撤回，现有站点未受影响。请把上面的报错发给 Claude"; exit 1; fi
  if command -v certbot >/dev/null 2>&1; then certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos --register-unsafely-without-email --redirect && echo "-> HTTPS 证书已申请"; else echo "没找到 certbot，HTTPS 还没配。把这句话发给 Claude，我来给你下一步命令"; fi
else
  echo "没找到 Caddy 或 Nginx。服务本身已在运行，只差网站入口，请把这段输出发给 Claude"
fi

echo
echo "== 完成 =="
echo "网页版：https://$DOMAIN"
echo "后台管理：https://$DOMAIN/_/   （用刚才的管理员邮箱和密码登录）"
echo "家人注册邀请码：$INVITE   （改邀请码：编辑 $DIR/env 后执行 systemctl restart shengxin）"
