/// <reference path="../pb_data/types.d.ts" />
// 省心：初始化数据结构
migrate((app) => {
  // 用户：关闭公开注册（改走邀请码接口），增加个人偏好
  const users = app.findCollectionByNameOrId("users");
  users.createRule = null;
  users.fields.add(new JSONField({ name: "prefs", maxSize: 200000 }));
  app.save(users);

  const ownerOnly = "owner = @request.auth.id";
  const tasks = new Collection({
    type: "base",
    name: "tasks",
    listRule: ownerOnly,
    viewRule: ownerOnly,
    createRule: "@request.auth.id != '' && @request.body.owner = @request.auth.id",
    updateRule: ownerOnly + " && (@request.body.owner:isset = false || @request.body.owner = @request.auth.id)",
    deleteRule: ownerOnly,
    fields: [
      { name: "owner", type: "relation", collectionId: users.id, required: true, maxSelect: 1, cascadeDelete: true },
      { name: "title", type: "text", max: 500 },
      { name: "notes", type: "text", max: 10000 },
      { name: "date", type: "text", max: 10 },
      { name: "allDay", type: "bool" },
      { name: "start", type: "text", max: 5 },
      { name: "end", type: "text", max: 5 },
      { name: "remind", type: "json", maxSize: 2000 },
      { name: "repeat", type: "json", maxSize: 5000 },
      { name: "done", type: "bool" },
      { name: "doneAt", type: "number" },
      { name: "ex", type: "json", maxSize: 500000 },
      { name: "deleted", type: "bool" },
      { name: "cu", type: "number" },
      { name: "created", type: "autodate", onCreate: true, onUpdate: false },
      { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
    ],
    indexes: [
      "CREATE INDEX idx_tasks_owner_updated ON tasks (owner, updated)",
    ],
  });
  app.save(tasks);

  const s = app.settings();
  s.meta.appName = "省心";
  s.rateLimits.enabled = true;
  s.trustedProxy.headers = ["X-Forwarded-For"];
  s.trustedProxy.useLeftmostIP = false;
  app.save(s);
}, (app) => {
  try { app.delete(app.findCollectionByNameOrId("tasks")); } catch (_) {}
  const users = app.findCollectionByNameOrId("users");
  users.fields.removeByName("prefs");
  users.createRule = "";
  app.save(users);
});
