/// <reference path="../pb_data/types.d.ts" />
// 邀请码注册：只有知道邀请码的人才能开账号。邀请码在服务器环境变量 SX_INVITE 里设置。
routerAdd("POST", "/api/sx/register", (e) => {
  const body = e.requestInfo().body || {};
  const invite = String($os.getenv("SX_INVITE") || "");
  const code = String(body.code || "").trim();
  const email = String(body.email || "").trim().toLowerCase();
  const password = String(body.password || "");
  const name = String(body.name || "").trim().slice(0, 40);
  if (!invite || code !== invite) return e.json(403, { message: "邀请码不正确" });
  if (!/^[^@\s]+@[^@\s]+$/.test(email)) return e.json(400, { message: "账号格式不正确" });
  if (password.length < 8) return e.json(400, { message: "密码至少 8 位" });
  try { e.app.findAuthRecordByEmail("users", email); return e.json(409, { message: "这个账号已经存在" }); } catch (_) {}
  const col = e.app.findCollectionByNameOrId("users");
  const rec = new Record(col);
  rec.set("email", email);
  rec.setPassword(password);
  rec.set("name", name);
  rec.set("verified", true);
  e.app.save(rec);
  return e.json(200, { ok: true });
});
